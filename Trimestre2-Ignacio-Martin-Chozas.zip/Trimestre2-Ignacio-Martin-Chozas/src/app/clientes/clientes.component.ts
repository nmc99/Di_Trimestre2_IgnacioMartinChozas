import { Component, OnInit } from '@angular/core';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-clientes',
  templateUrl: './clientes.component.html',
  styleUrls: ['./clientes.component.css']
})
export class ClientesComponent implements OnInit {

  clientes = [];
  constructor(private api: ApiService) {

    this.api.getUsers().subscribe(response => {
      this.clientes = response['results'];
      console.log(response['results']);
      console.log(this.clientes)
    })

  }

  ngOnInit(): void {
  }

}
